const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const Checklist = require("./models/checklist");

const userRoutes = require("./routes/user");

const app = express();

mongoose
  .connect(
    "mongodb+srv://amol:vZXgyIS4vbokLpAG@cluster0.9envj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS"
  );
  next();
});

app.post("/api/checklists", (req, res, next) => {
  const checklist = new Checklist({
    title: req.body.title,
    status: 'New'
  });
  checklist.save().then(createdChecklist=> {
    res.status(201).json({
      message: "Checklist added successfully",
      checklistId: createdChecklist._id
    });
  });
});

app.get("/api/checklists", (req, res, next) => {
  Checklist.find().then(documents => {
    res.status(200).json({
      message: "Checklist fetched successfully!",
      checklists: documents
    });
  });
});

app.delete("/api/checklists/:id", (req, res, next) => {
  Checklist.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json({ message: "Checklist deleted!" });
  });
});

app.use("/api/user", userRoutes);

module.exports = app;
